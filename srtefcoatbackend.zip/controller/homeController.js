const db = require('../config/db');

// Get Home by single field
exports.getHomeDetails = async (req, res) => {

    try {
        // Construct safe query using parameterized column name
        const query = `SELECT * FROM homedata WHERE page='home'`;
        const [rows] = await db.query(query);
        res.json({ homeDetails: rows });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

